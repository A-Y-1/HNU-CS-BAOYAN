/**
 * @program: STJUAssignment
 * @description:
 * @author: Annntn
 * @create: 2018-07-16 15:39
 **/

public class AlgPart {
}
