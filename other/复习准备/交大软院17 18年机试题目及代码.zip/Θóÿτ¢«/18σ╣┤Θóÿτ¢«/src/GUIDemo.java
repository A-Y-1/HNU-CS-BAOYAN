import javax.swing.*;

/**
 * @program: STJUAssignment
 * @description:
 * @author: Annntn
 * @create: 2018-07-16 15:38
 **/

public class GUIDemo {
    public static void main(String[] args) {
        JFrame frame = new JFrame();

        frame.setSize(500,500);
        frame.setVisible(true);
    }
}
